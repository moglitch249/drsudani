import 'dart:async';
import 'dart:ui' as dart_ui;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:carousel_slider/carousel_slider.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/theme/app_dimensions.dart';
import '../../../../core/widgets/ds_app_bar.dart';
import '../../../../core/widgets/ds_product_card.dart';
import '../../../../core/widgets/ds_shimmer.dart';
import '../../../../core/widgets/ds_empty_state.dart';
import '../../../product/data/models/product_model.dart';
import '../bloc/home_cubit.dart';
import '../bloc/home_state.dart';
import '../../../profile/presentation/bloc/wallet_cubit.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../core/l10n/app_localizations.dart';
import '../../../notifications/presentation/bloc/notifications_cubit.dart';
import '../../../cart/presentation/bloc/cart_cubit.dart';
import '../../../cart/presentation/bloc/cart_state.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';
import '../../../auth/presentation/bloc/auth_state_event.dart';
import '../../../../core/utils/price_formatter.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final PageController _bannerController = PageController();
  int _currentBanner = 0;
  Timer? _bannerTimer;

  final PageController _adsController = PageController();
  int _currentAd = 0;
  Timer? _adsTimer;

  @override
  void initState() {
    super.initState();
    _startBannerTimer();
    _startAdsTimer();
  }

  void _startBannerTimer() {
    _bannerTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (_bannerController.hasClients) {
        final state = context.read<HomeCubit>().state;
        if (state is HomeLoaded && state.banners.isNotEmpty) {
          int next = (_currentBanner + 1) % state.banners.length;
          _bannerController.animateToPage(
            next,
            duration: const Duration(milliseconds: 500),
            curve: Curves.easeInOut,
          );
        }
      }
    });
  }

  void _startAdsTimer() {
    _adsTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (_adsController.hasClients) {
        final state = context.read<HomeCubit>().state;
        if (state is HomeLoaded && state.ads.isNotEmpty) {
          int next = (_currentAd + 1) % state.ads.length;
          _adsController.animateToPage(
            next,
            duration: const Duration(milliseconds: 500),
            curve: Curves.easeInOut,
          );
        }
      }
    });
  }

  @override
  void dispose() {
    _bannerTimer?.cancel();
    _bannerController.dispose();
    _adsTimer?.cancel();
    _adsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocBuilder<HomeCubit, HomeState>(
        builder: (context, state) {
          if (state is HomeLoading || state is HomeInitial) {
            return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
          } else if (state is HomeError) {
            return Center(
              child: DsEmptyState(
                icon: Icons.wifi_off,
                title: l10n.connectionError,
                subtitle: state.message,
                buttonText: l10n.retry,
                onButtonPressed: () => context.read<HomeCubit>().loadHomeData(),
              ),
            );
          } else if (state is HomeLoaded) {
            return CustomScrollView(
              slivers: [
                const DsAppBar(title: ''),
                SliverList(
                  delegate: SliverChildListDelegate([
                    SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildHeader(context, l10n),
                          _buildBalanceCard(context, l10n),
                          const SizedBox(height: AppDimensions.lg),
                          _buildSlider(context, state, l10n),
                          const SizedBox(height: AppDimensions.lg),
                          _buildQuickCategories(context, state, l10n),
                          const SizedBox(height: AppDimensions.lg),
                          _buildSectionGrid(context, 'الأكثر مبيعاً', state.popularProducts),
                          if (state.onSaleProducts.isNotEmpty)
                            _buildSectionGrid(context, 'العروض الحصرية', state.onSaleProducts),
                            
                          if (state.ads.isNotEmpty) 
                            _buildAdsSlider(context, state, l10n),

                          if (state.randomProducts.isNotEmpty)
                            _buildSectionGrid(context, 'اقتراحات لك', state.randomProducts),
                          const SizedBox(height: AppDimensions.xl),
                          _buildArticles(context, state, l10n),
                          const SizedBox(height: AppDimensions.xxl),
                        ],
                      ),
                    ),
                  ]),
                ),
              ],
            );
          }
          return const SizedBox();
        },
      ),
    );
  }

  Widget _buildHeader(BuildContext context, AppLocalizations l10n) {
    return Padding(
      padding: const EdgeInsets.all(AppDimensions.md),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Welcome and Status
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  BlocBuilder<AuthBloc, AuthState>(
                    builder: (context, authState) {
                      String displayName = 'User';
                      // Prefer firstName from WalletLoaded if available
                      final walletState = context.read<WalletCubit>().state;
                      if (walletState is WalletLoaded && walletState.firstName != null && walletState.firstName!.isNotEmpty) {
                        displayName = walletState.firstName!;
                      } else if (authState is AuthSuccess) {
                        displayName = authState.user.firstName.isNotEmpty ? authState.user.firstName : authState.user.email.split('@')[0];
                      }
                      return Text(
                        '${l10n.welcome} $displayName ',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.onSurface,
                        ),
                      );
                    },
                  ),
                  const Text(
                    '👋',
                    style: TextStyle(fontSize: 16),
                  )
                  .animate(onPlay: (controller) => controller.repeat(reverse: true))
                  .rotate(begin: -0.1, end: 0.2, duration: 800.ms, curve: Curves.easeInOut), // Waving hand
                ],
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: AppTheme.success,
                      shape: BoxShape.circle,
                    ),
                  )
                  .animate(onPlay: (controller) => controller.repeat(reverse: true))
                  .fade(begin: 0.3, end: 1.0, duration: 1.seconds), // Pulsing dot
                  const SizedBox(width: 6),
                  Text(
                    l10n.activeAccount,
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppTheme.success,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ],
          ),
          
          // Dummy Coupon placed in the empty space
          const _DummyCouponWidget(),
        ],
      ),
    );
  }

  Widget _buildBalanceCard(BuildContext context, AppLocalizations l10n) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppDimensions.md),
      child: BlocBuilder<WalletCubit, WalletState>(
        builder: (context, state) {
          double balance = 0.0;
          if (state is WalletLoaded) {
            balance = state.balance;
          }
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppTheme.primary.withOpacity(0.15),
                  AppTheme.primary.withOpacity(0.05),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.primary.withOpacity(0.2)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withOpacity(0.2),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.account_balance_wallet_outlined, color: AppTheme.primary, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          l10n.walletBalance,
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                          ),
                        ),
                        Text(
                          PriceFormatter.formatWithCurrency(balance, l10n.locale.languageCode == 'ar', withDecimals: true),
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).colorScheme.onSurface,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                ElevatedButton(
                  onPressed: () => context.push('/wallet'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    minimumSize: Size.zero,
                  ),
                  child: Text(l10n.locale.languageCode == 'ar' ? 'تعبئة الرصيد' : 'Top Up', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildSlider(BuildContext context, HomeLoaded state, AppLocalizations l10n) {
    final displayBanners = state.banners.isNotEmpty 
        ? state.banners 
        : state.popularProducts.map((p) => p.imageUrl).take(3).toList();
    
    if (displayBanners.isEmpty) {
      return SizedBox(height: 180, child: Center(child: Text(l10n.noOffers)));
    }

    return Column(
      children: [
        SizedBox(
          height: 200,
          child: PageView.builder(
            controller: _bannerController,
            onPageChanged: (index) {
              setState(() => _currentBanner = index);
            },
            itemCount: displayBanners.length,
            itemBuilder: (context, index) {
              final imageUrl = displayBanners[index];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: AppDimensions.md),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  image: DecorationImage(
                    image: CachedNetworkImageProvider(
                      imageUrl.isNotEmpty ? imageUrl : 'assets/images/drsudani.png',
                    ),
                    fit: BoxFit.cover,
                  ),
                  boxShadow: [
                    BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 8)),
                  ],
                ),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [Colors.black.withOpacity(0.6), Colors.transparent],
                    ),
                  ),
                  alignment: Alignment.bottomRight,
                  padding: const EdgeInsets.all(AppDimensions.md),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text('${index + 1} / ${displayBanners.length}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: AppDimensions.md),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(displayBanners.length, (index) {
            final isSelected = _currentBanner == index;
            return AnimatedContainer(
              duration: 300.ms,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: isSelected ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                color: _currentBanner == index ? AppTheme.primary : Colors.grey[300],
                borderRadius: BorderRadius.circular(4),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickCategories(BuildContext context, HomeLoaded state, AppLocalizations l10n) {
    if (state.categories.isEmpty) return const SizedBox();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppDimensions.md),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(AppLocalizations.of(context)!.shopByCategory, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Theme.of(context).colorScheme.onSurface)),
          const SizedBox(height: AppDimensions.md),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: state.categories.map((cat) => _buildCategoryCard(context, cat)).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryCard(BuildContext context, ProductCategory cat) {
    return GestureDetector(
      onTap: () {
        context.push('/category/${cat.id}/${Uri.encodeComponent(cat.name)}');
      },
      child: Container(
        width: 80,
        margin: const EdgeInsets.only(left: AppDimensions.md),
        child: Column(
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Theme.of(context).cardColor.withOpacity(0.3),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 4)),
                ],
              ),
              child: ClipOval(
                child: cat.imageUrl.isNotEmpty
                    ? (cat.imageUrl.toLowerCase().endsWith('.svg')
                        ? SvgPicture.network(
                            cat.imageUrl,
                            fit: BoxFit.cover,
                            placeholderBuilder: (BuildContext context) => const Icon(Icons.category, color: AppTheme.primary, size: 28),
                          )
                        : CachedNetworkImage(
                            imageUrl: cat.imageUrl,
                            fit: BoxFit.cover,
                            errorWidget: (context, url, error) => const Icon(Icons.category, color: AppTheme.primary, size: 28),
                          ))
                    : const Icon(Icons.category, color: AppTheme.primary, size: 28),
              ),
            ),
            const SizedBox(height: AppDimensions.sm),
            Text(
              cat.name, 
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.onSurface), 
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }



  Widget _buildAdsSlider(BuildContext context, HomeLoaded state, AppLocalizations l10n) {
    if (state.ads.isEmpty) return const SizedBox.shrink();

    return Column(
      children: [
        CarouselSlider.builder(
          itemCount: state.ads.length,
          options: CarouselOptions(
            height: 140,
            autoPlay: true,
            autoPlayInterval: const Duration(seconds: 4),
            enlargeCenterPage: true,
            viewportFraction: 0.9,
            onPageChanged: (index, reason) {
              setState(() => _currentAd = index);
            },
          ),
          itemBuilder: (context, index, realIndex) {
            final imageUrl = state.ads[index];
            return Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                  image: CachedNetworkImageProvider(imageUrl),
                  fit: BoxFit.cover,
                ),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 5)),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: AppDimensions.md),
        if (state.ads.length > 1)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(state.ads.length, (index) {
              final isSelected = _currentAd == index;
              return AnimatedContainer(
                duration: 300.ms,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: isSelected ? 24 : 8,
                height: 8,
                decoration: BoxDecoration(
                  color: isSelected ? AppTheme.primary : Colors.grey[300],
                  borderRadius: BorderRadius.circular(4),
                ),
              );
            }),
          ),
        const SizedBox(height: AppDimensions.lg),
      ],
    );
  }

  Widget _buildSectionGrid(BuildContext context, String title, List<ProductModel> products) {
    if (products.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppDimensions.md),
          child: Text(title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Theme.of(context).colorScheme.onSurface)),
        ),
        const SizedBox(height: AppDimensions.md),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppDimensions.md),
          child: GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.75,
              crossAxisSpacing: AppDimensions.md,
              mainAxisSpacing: AppDimensions.md,
            ),
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              return DsProductCard(
                id: product.id.toString(),
                imageUrl: product.imageUrl.isNotEmpty ? product.imageUrl : 'assets/images/drsudani.png',
                name: product.name,
                startingPrice: double.tryParse(product.price) ?? 0.0,
                regularPrice: double.tryParse(product.regularPrice) ?? 0.0,
                salePrice: double.tryParse(product.salePrice) ?? 0.0,
                isPopular: title.contains('الأكثر'), // Only show popular badge if it's the popular section
                onTap: () => context.push('/product/${product.id}'),
              );
            },
          ),
        ),
        const SizedBox(height: AppDimensions.xl),
      ],
    );
  }

  Widget _buildArticles(BuildContext context, HomeLoaded state, AppLocalizations l10n) {
    if (state.articles.isEmpty) return const SizedBox.shrink();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppDimensions.lg),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(l10n.latestArticles, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              TextButton(
                onPressed: () async {
                  final url = Uri.parse('https://drsudani.com/blog');
                  if (await canLaunchUrl(url)) {
                    await launchUrl(url, mode: LaunchMode.externalApplication);
                  }
                },
                child: Text(l10n.viewAll),
              ),
            ],
          ),
        ),
        const SizedBox(height: AppDimensions.sm),
        SizedBox(
          height: 200,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: AppDimensions.lg),
            scrollDirection: Axis.horizontal,
            itemCount: state.articles.length,
            separatorBuilder: (_, __) => const SizedBox(width: AppDimensions.md),
            itemBuilder: (context, index) {
              final article = state.articles[index];
              return GestureDetector(
                onTap: () async {
                  // Fallback for missing link property (just an example). 
                  // If ArticleModel doesn't have link, it's fine to just catch error or do nothing if link doesn't exist.
                  // We'll open WP site.
                  final url = Uri.parse(article.link);
                  if (await canLaunchUrl(url)) {
                    await launchUrl(url);
                  }
                },
                child: Container(
                  width: 280,
                  decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(AppDimensions.radiusLg),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    )
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      flex: 3,
                      child: ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(AppDimensions.radiusLg)),
                        child: article.imageUrl.isNotEmpty
                            ? CachedNetworkImage(
                                imageUrl: article.imageUrl,
                                width: double.infinity,
                                fit: BoxFit.cover,
                                errorWidget: (context, url, error) => Image.asset('assets/images/drsudani.png', fit: BoxFit.cover),
                              )
                            : Container(color: AppTheme.surfaceVariant, child: const Center(child: Icon(Icons.article, color: AppTheme.primary, size: 40))),
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Padding(
                        padding: const EdgeInsets.all(AppDimensions.md),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              article.title,
                              style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const Spacer(),
                            Text(
                              article.date.split('T')[0],
                              style: Theme.of(context).textTheme.labelSmall?.copyWith(color: AppTheme.textMuted),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _DummyCouponWidget extends StatefulWidget {
  const _DummyCouponWidget({Key? key}) : super(key: key);

  @override
  State<_DummyCouponWidget> createState() => _DummyCouponWidgetState();
}

class _DummyCouponWidgetState extends State<_DummyCouponWidget> {
  late Timer _timer;
  Duration _duration = const Duration(hours: 5, minutes: 20, seconds: 15);

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_duration.inSeconds > 0) {
        if (mounted) setState(() => _duration -= const Duration(seconds: 1));
      } else {
        timer.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(_duration.inHours);
    final minutes = twoDigits(_duration.inMinutes.remainder(60));
    final seconds = twoDigits(_duration.inSeconds.remainder(60));

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppTheme.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.primary.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('كوبون: DRSUDANI', style: const TextStyle(color: AppTheme.primary, fontSize: 10, fontWeight: FontWeight.bold)),
          Text('$hours:$minutes:$seconds', style: const TextStyle(color: AppTheme.primary, fontSize: 11, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
