import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/l10n/app_localizations.dart';
import 'core/network/api_service.dart';

import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'core/utils/locale_cubit.dart';
import 'core/utils/theme_cubit.dart';
import 'core/di/injection.dart';
import 'features/auth/presentation/bloc/auth_bloc.dart';
import 'features/auth/presentation/bloc/auth_state_event.dart';
import 'features/home/presentation/bloc/home_cubit.dart';
import 'features/product/presentation/bloc/product_cubit.dart';
import 'features/cart/presentation/bloc/cart_cubit.dart';
import 'features/profile/presentation/bloc/wallet_cubit.dart';
import 'features/notifications/presentation/bloc/notifications_cubit.dart';
import 'features/auth/data/datasources/auth_local_data_source.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  configureDependencies();

  // Initialize Hive
  await Hive.initFlutter();
  await Hive.openBox('settings');
  await Hive.openBox('auth');
  await Hive.openBox('cart');
  await Hive.openBox('notificationsBox');

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<LocaleCubit>(create: (_) => LocaleCubit()..loadSavedLocale()),
        BlocProvider<ThemeCubit>(create: (_) => ThemeCubit()..loadSavedTheme()),
        BlocProvider<AuthBloc>(create: (_) => getIt<AuthBloc>()),
        BlocProvider<ProductCubit>(create: (_) => getIt<ProductCubit>()),
        BlocProvider<CartCubit>(create: (_) => CartCubit()),
        BlocProvider<WalletCubit>(create: (_) => WalletCubit(getIt<ApiService>())),
        BlocProvider<NotificationsCubit>(create: (_) {
          final localDs = getIt<AuthLocalDataSource>();
          final customerId = localDs.getUserId() ?? 0;
          return NotificationsCubit(
            apiService: getIt<ApiService>(),
            customerId: customerId,
          )..loadNotifications();
        }),
      ],
      child: BlocListener<AuthBloc, AuthState>(
        listener: (context, authState) {
          if (authState is AuthSuccess) {
            // نمرر التوكن مباشرة من الـ state لتجنب أي مشكلة في Hive
            context.read<WalletCubit>().fetchWalletData(authToken: authState.user.token);
            context.read<NotificationsCubit>().checkForUpdates();
          } else if (authState is AuthInitial || authState is AuthError) {
            context.read<CartCubit>().clearCart();
          }
        },
        child: BlocBuilder<LocaleCubit, Locale>(
          builder: (context, locale) {
            return BlocBuilder<ThemeCubit, ThemeMode>(
              builder: (context, themeMode) {
                return MaterialApp.router(
                  title: 'Dr. Sudani',
                  debugShowCheckedModeBanner: false,
                  themeMode: themeMode,
                  theme: AppTheme.getLightTheme(locale.languageCode),
                  darkTheme: AppTheme.getDarkTheme(locale.languageCode),
                  locale: locale,
                  supportedLocales: const [
                    Locale('en'),
                    Locale('ar'),
                  ],
                  localizationsDelegates: const [
                    AppLocalizations.delegate,
                    GlobalMaterialLocalizations.delegate,
                    GlobalWidgetsLocalizations.delegate,
                    GlobalCupertinoLocalizations.delegate,
                  ],
                  routerConfig: AppRouter.router,
                  builder: (context, child) {
                    return Directionality(
                      textDirection: locale.languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr,
                      child: child!,
                    );
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }
}
