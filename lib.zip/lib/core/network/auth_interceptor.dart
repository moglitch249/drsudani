import 'package:dio/dio.dart';
import 'package:hive_flutter/hive_flutter.dart';

class AuthInterceptor extends Interceptor {
  // سر التطبيق — يجب أن يطابق DS_APP_SECRET في PHP plugin
  // هذه القيمة مدمجة داخل الـ Binary ومصعب استخراجها بدون reverse engineering
  static const String _appSecret = 'drsudani-mobile-v1-x9k2p7q4';

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    // === Layer 1: App Secret — يُثبت أن الطلب من تطبيق DrSudani ===
    options.headers['X-App-Secret'] = _appSecret;
    options.queryParameters['app_secret'] = _appSecret;

    // === Layer 2: JWT Token — يُثبت هوية المستخدم المسجل ===
    final token = Hive.box('auth').get('jwtToken');
    if (token != null) {
      options.headers['Authorization'] = 'Bearer $token';
      options.queryParameters['JWT_TOKEN'] = token; // Fallback for strict servers
    }

    super.onRequest(options, handler);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    // لا نحذف التوكن تلقائياً هنا لأن 401 قد يكون من endpoint محدد
    // (مثل المحفظة) وليس بالضرورة أن التوكن منتهي
    // التعامل مع 401 يتم داخل كل Cubit على حدة
    super.onError(err, handler);
  }
}
