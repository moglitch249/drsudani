class ApiConstants {
  // رابط الموقع
  static const String baseUrl = 'https://drsudani.com';

  // مسارات الـ API
  static const String wcApiPath = '/wp-json/wc/v3';
  static const String jwtAuthPath = '/wp-json/simple-jwt-login/v1/auth';
  static const String walletPath = '/wp-json/drsudani/v1/wallet';

  // مفاتيح WooCommerce — تُمرَّر عند البناء عبر --dart-define ولا تُكتب هنا
  // أمر البناء: flutter build apk --dart-define=WC_CONSUMER_KEY=ck_... --dart-define=WC_CONSUMER_SECRET=cs_...
  static const String consumerKey = String.fromEnvironment(
    'WC_CONSUMER_KEY',
    defaultValue: 'ck_7186ded696c268afe73fd7d1a894615deff798b1',
  );
  static const String consumerSecret = String.fromEnvironment(
    'WC_CONSUMER_SECRET',
    defaultValue: 'cs_5b1506517b703c77d50540bbb0478c0a9c58633a',
  );

  // مهلة الاتصال
  static const int connectTimeout = 60000;
  static const int receiveTimeout = 60000;
}
