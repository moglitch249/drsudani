import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_theme.dart';
import '../theme/app_dimensions.dart';
import '../l10n/app_localizations.dart';
import '../utils/price_formatter.dart';

class DsProductCard extends StatefulWidget {
  final String id;
  final String imageUrl;
  final String name;
  final double startingPrice; // Keep for backward compatibility or when prices are 0
  final double regularPrice;
  final double salePrice;
  final bool isPopular;
  final VoidCallback onTap;

  const DsProductCard({
    Key? key,
    required this.id,
    required this.imageUrl,
    required this.name,
    this.startingPrice = 0.0,
    this.regularPrice = 0.0,
    this.salePrice = 0.0,
    this.isPopular = false,
    required this.onTap,
  }) : super(key: key);

  @override
  State<DsProductCard> createState() => _DsProductCardState();
}

class _DsProductCardState extends State<DsProductCard> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    final isAr = AppLocalizations.of(context)?.locale.languageCode == 'ar';
    final hasDiscount = widget.salePrice > 0 && widget.regularPrice > widget.salePrice;
    final currentPrice = widget.salePrice > 0 ? widget.salePrice : (widget.regularPrice > 0 ? widget.regularPrice : widget.startingPrice);

    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) {
        setState(() => _isPressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _isPressed = false),
      child: AnimatedScale(
        scale: _isPressed ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOutBack,
        child: Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: AppTheme.primary.withOpacity(0.08),
                blurRadius: 15,
                offset: const Offset(0, 8),
              )
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Top Half: Image with Wave Clipper
              Expanded(
                flex: 70,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    ClipPath(
                      clipper: _WaveClipper(),
                      child: Hero(
                        tag: 'product_image_${widget.id}',
                        child: CachedNetworkImage(
                          imageUrl: widget.imageUrl.isNotEmpty ? widget.imageUrl : 'error',
                          fit: BoxFit.cover,
                          placeholder: (context, url) => Container(
                            color: Theme.of(context).scaffoldBackgroundColor,
                            child: const Center(
                              child: CircularProgressIndicator(color: AppTheme.primary),
                            ),
                          ),
                          errorWidget: (context, url, error) => Image.asset('assets/images/drsudani.png', fit: BoxFit.cover),
                        ),
                      ),
                    ),
                    
                    // Discount Badge
                    if (hasDiscount)
                      Positioned(
                        top: 10,
                        left: isAr ? null : 10,
                        right: isAr ? 10 : null,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppTheme.error,
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: [
                              BoxShadow(color: AppTheme.error.withOpacity(0.3), blurRadius: 4, offset: const Offset(0, 2)),
                            ],
                          ),
                          child: Text(
                            '${((widget.regularPrice - widget.salePrice) / widget.regularPrice * 100).round()}%',
                            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ).animate().fade().scale(),

                    // Popular Badge
                    if (widget.isPopular)
                      Positioned(
                        top: 10,
                        right: isAr ? null : 10,
                        left: isAr ? 10 : null,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppTheme.primary,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(color: AppTheme.primary.withOpacity(0.3), blurRadius: 4, offset: const Offset(0, 2)),
                            ],
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.local_fire_department, color: Colors.white, size: 12),
                              const SizedBox(width: 2),
                              Text(
                                isAr ? 'الأكثر مبيعاً' : 'Popular',
                                style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                      ).animate().scale(duration: 400.ms, curve: Curves.easeOutBack),
                  ],
                ),
              ),

              // 2. Bottom Half: Title and Price
              Expanded(
                flex: 30,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        widget.name,
                        style: TextStyle(
                          color: Theme.of(context).textTheme.bodyLarge?.color,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          height: 1.2,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ).animate().fade(duration: 400.ms).slideY(begin: 0.1),
                      
                      const Spacer(),
                      
                      // Price Area
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (hasDiscount)
                                  Text(
                                    PriceFormatter.formatWithCurrency(widget.regularPrice, isAr),
                                    style: TextStyle(
                                      color: Theme.of(context).textTheme.bodySmall?.color?.withOpacity(0.5),
                                      fontSize: 10,
                                      decoration: TextDecoration.lineThrough,
                                    ),
                                  ),
                                Text(
                                  PriceFormatter.formatWithCurrency(currentPrice, isAr),
                                  style: TextStyle(
                                    color: hasDiscount ? AppTheme.primary : Theme.of(context).textTheme.bodyLarge?.color,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: AppTheme.primary.withOpacity(0.1),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.arrow_forward_ios, size: 12, color: AppTheme.primary),
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height - 10);
    
    var firstControlPoint = Offset(size.width / 4, size.height);
    var firstEndPoint = Offset(size.width / 2, size.height - 10);
    path.quadraticBezierTo(
        firstControlPoint.dx, firstControlPoint.dy, firstEndPoint.dx, firstEndPoint.dy);

    var secondControlPoint = Offset(size.width * 0.75, size.height - 20);
    var secondEndPoint = Offset(size.width, size.height - 10);
    path.quadraticBezierTo(
        secondControlPoint.dx, secondControlPoint.dy, secondEndPoint.dx, secondEndPoint.dy);

    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
